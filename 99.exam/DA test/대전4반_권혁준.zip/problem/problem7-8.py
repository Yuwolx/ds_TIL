import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 데이터 로드
file_path = 'data/dementia_dataset.csv'
data = pd.read_csv(file_path)

################### 코드 작성 ###################
# 문제 07. 성별(M/F)과 치매 발병 여부(Group)에 따라 뇌 용적 비율(nWBV)의 차이를 Boxplot으로 비교하세요.

# df0 = data.groupby('Group')['M/F','nWBV']
# print(df0.head())

# ###############################################
# plt.boxplot(df1)
# plt.title("nWBV by Gender and Dementia Group")
# plt.legend()
# plt.xlabel("Gender")
# plt.ylabel("nWBV")
# plt.show()

################### 코드 작성 ###################
# 문제 08. Group이 ‘Demented’인 사람들의 데이터를 필터링하고, 성별별 치매 발병률을 계산하고, 이를 막대 그래프로 시각화하시오.
df1 = data[data['Group'] == 'Demented']
df2 = df1.groupby('M/F').count()
df3 = df2['Group']
df4 = data.groupby('M/F').count()
df5 = df4['Group']
f1 = df3['F']
f0 = df5['F']
m1 = df3['M']
m0 = df5['M']
ff = f1/f0*100
mm = m1/m0*100



###############################################
plt.bar(['F','M'],[ff,mm],0.5,0)
plt.title('Dementia Incidence Rate by Gender (%)')
plt.xlabel('Gender')
plt.ylabel('Dementia Incidence Rate (%)')
plt.show()

